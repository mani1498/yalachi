### Angular 2 Documentation Example 

Router