import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule }    from '@angular/http';
import { FormsModule }   from '@angular/forms';

import { AppComponent }  from './app.component';
import { ContractorComponent }  from './contractor/contractor.component';
//import { ContractorEditComponent }  from './contractor/contractor-edit.component';
//import { ContractorCreateComponent }  from './contractor/contractor-add.component';
import { HomeComponent }  from './home/home.component';
import { ContractorService }  from './contractor/contractor.service';

import { routing }        from './routers/app.routing';

@NgModule({
  imports:      [
    BrowserModule,
    HttpModule,
    routing,
    FormsModule
  ],
  declarations: [
    AppComponent,
    ContractorComponent,
    HomeComponent
  ],
  providers: [
    ContractorService,
  ],
  bootstrap:    [
    AppComponent
  ]
})
export class AppModule { }
