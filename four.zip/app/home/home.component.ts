import { Component } from '@angular/core';

@Component({
    selector: 'home',
    templateUrl: './app/home/layout.html',
})
export class HomeComponent {
}
