import { Routes, RouterModule } from '@angular/router';

import { ContractorComponent }     from '../contractor/contractor.component';

import { ContractorListComponent }     from '../contractor/contractor-list.component';
import { ContractorEditComponent }     from '../contractor/contractor-edit.component';
import { ContractorCreateComponent }     from '../contractor/contractor-add.component';
import { ContractorDeleteComponent }     from '../contractor/contractor-delete.component';

import { LoginComponent }      from '../login/login.component';
import { HomeComponent }  from '../home/home.component';

const appRoutes: Routes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'settings',
        component: HomeComponent,
        children: [
            {
                path: 'contractor',
                component: ContractorComponent,
                children: [
                    {
                        path: '',
                        component: ContractorListComponent,
                    },
                    {
                        path: 'edit/:id',
                        component: ContractorEditComponent,
                    },
                    {
                        path: 'delete/:id',
                        component: ContractorDeleteComponent,
                    },
                    {
                        path: 'create',
                        component: ContractorCreateComponent,
                    }
                    ]
            }

        ]
    }
    
    /*{
        path: 'settings',
        component: HomeComponent,
        children: [
                    {
                        path: '',
                        component: ContractorListComponent,
                    },
                    {   path: 'contractor',
                        component: ContractorComponent
                    },
                    {
                        path: 'contractor/edit/:id',
                        component: ContractorEditComponent,
                    },
                    {
                        path: 'contractor/create',
                        component: ContractorCreateComponent,
                    }
        ]
    }*/
];
export const routing = RouterModule.forRoot(appRoutes);

