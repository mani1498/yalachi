"use strict";
var router_1 = require('@angular/router');
var contractor_component_1 = require('../contractor/contractor.component');
var contractor_list_component_1 = require('../contractor/contractor-list.component');
var contractor_edit_component_1 = require('../contractor/contractor-edit.component');
var contractor_add_component_1 = require('../contractor/contractor-add.component');
var contractor_delete_component_1 = require('../contractor/contractor-delete.component');
var login_component_1 = require('../login/login.component');
var home_component_1 = require('../home/home.component');
var appRoutes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: login_component_1.LoginComponent
    },
    {
        path: 'settings',
        component: home_component_1.HomeComponent,
        children: [
            {
                path: 'contractor',
                component: contractor_component_1.ContractorComponent,
                children: [
                    {
                        path: '',
                        component: contractor_list_component_1.ContractorListComponent,
                    },
                    {
                        path: 'edit/:id',
                        component: contractor_edit_component_1.ContractorEditComponent,
                    },
                    {
                        path: 'delete/:id',
                        component: contractor_delete_component_1.ContractorDeleteComponent,
                    },
                    {
                        path: 'create',
                        component: contractor_add_component_1.ContractorCreateComponent,
                    }
                ]
            }
        ]
    }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map