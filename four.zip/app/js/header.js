$(document).ready(function() {
	$(document).on("click", "#ems_headernav", function() {
		$("body").toggleClass("sidebar-collapse");
	});

	$(document).on('click', '.sidebar-menu .clickable_menu', function() {
		if ($(window).width() <= 767) {
			$("body").toggleClass("sidebar-collapse");
		}
	});

	// Back to top window scroll
	$(document).on('click', '.back-to-top', function() {
		$('html,body').animate({
			scrollTop : 0
		}, 'slow');
	});
	
	// Check mobile devices
	var checkMobileDevice = function() { 
		if ($(window).innerWidth() < 992) {
			$('body').addClass('mobile-device');
		} else {
			if ($('body').hasClass('mobile-device')) {
				$('body').removeClass('mobile-device');
			}
		}
	};
	// For On ready state
	checkMobileDevice();
	
	// Menu Resize event for page content
	$(window).bind('resize', function() {
		// For Page layout
		checkMobileDevice();
	});
	
	
});

