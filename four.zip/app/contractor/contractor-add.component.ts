import { Component, ViewChild} from '@angular/core';
import {  Http, Response } from '@angular/http';
import { Router,ActivatedRoute }            from '@angular/router';
import { ContractorService }  from '../contractor/contractor.service';
import { MODAL_DIRECTIVES,ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';

import { contractorDataModel }  from '../contractor/contractor';
import { ErrorModel }  from '../contractor/error';

@Component({
    selector: 'project_edit',
    templateUrl: './app/contractor/contractor-add.html',
    directives: [MODAL_DIRECTIVES],
})
export class ContractorCreateComponent {
    public contractor:contractorDataModel;
    public contractor_error:ErrorModel;
    invEmail: boolean;
    emVal: boolean;
    @ViewChild('myModal')
    modal: ModalComponent;
    constructor(private http: Http, private _ContractorService : ContractorService, private router: Router) { 
        this.contractor_error = new ErrorModel();
        this.contractor = new contractorDataModel();
    }
    addContractor(email:string){
        if(email!='') {
           this._ContractorService.createContractor('/contractor','',email).subscribe(data=>{
                this.contractor=data;
                this.modal.close();
                this.router.navigate(['/settings/contractor/']);
            },
            err => {//console.log(err.json());
                this.contractor_error = err.json();
               // this.contractor_error.message = err.status;
                //this.contractor_error.FieldValidationErrors = err._body;
            }
           );
        }else
           this.emVal=true;
    }
    formStatus(e){console.log(e);
        this.invEmail=false;
        this.emVal= e == null ? true : false;
    }
    ngOnInit() {
        this.modal.open();
    }

    public close() {
        this.modal.close();this.router.navigate(['/settings/contractor/']);
    }

    public open() {
        this.modal.open();
    }
}
