import { Component, ViewChild} from '@angular/core';
import {  Http, Response } from '@angular/http';
import { Router,ActivatedRoute }            from '@angular/router';
import { ContractorService }  from '../contractor/contractor.service';
import { MODAL_DIRECTIVES,ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';

import { contractorDataModel }  from '../contractor/contractor';
import { ErrorModel }  from '../contractor/error';

@Component({
    selector: 'project_edit',
    templateUrl: './app/contractor/contractor-edit.html',
    directives: [MODAL_DIRECTIVES],
})
export class ContractorEditComponent {
    public contractor:contractorDataModel;
    public contractor_error:ErrorModel;
    public params:any;
    @ViewChild('myModal')
    modal: ModalComponent;
    constructor(private http: Http, private _ContractorService : ContractorService, private router: Router, private activatedRoute:ActivatedRoute) {
        this.contractor_error = new ErrorModel();
        this.contractor = new contractorDataModel();
     }
    getContractor(){
        this.activatedRoute.params.subscribe(params =>{
            this.params = params;
        })
        this._ContractorService.getContractor('/contractor/'+this.params.id,'').subscribe(data=>{
            this.contractor.contractorEmail=data.contractorEmail;
             this.contractor.contractorId=data.id;
        });
    }
    update(email:string,id:number){
       this._ContractorService.saveContractor('/contractor/'+id,'',email).subscribe(data=>{
            this.contractor=data;
            this.modal.close();
            this.router.navigate(['/settings/contractor/']);
        },
        err => { this.contractor_error = err.json();
            });
    }
    ngOnInit() {
        this.getContractor();
        this.modal.open();
    }

    public close() {
        this.modal.close();this.router.navigate(['/settings/contractor/']);
    }

    public open() {
        this.modal.open();
    }
}
