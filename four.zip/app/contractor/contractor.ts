export class contractorDataModel{
    contractorId: number;
    contractorEmail : string;
}