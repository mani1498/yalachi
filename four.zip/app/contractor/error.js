"use strict";
var ErrorModel = (function () {
    function ErrorModel() {
    }
    return ErrorModel;
}());
exports.ErrorModel = ErrorModel;
//# sourceMappingURL=error.js.map