"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require('@angular/router');
var contractor_service_1 = require('../contractor/contractor.service');
var ng2_bs3_modal_1 = require('ng2-bs3-modal/ng2-bs3-modal');
var contractor_1 = require('../contractor/contractor');
var error_1 = require('../contractor/error');
var ContractorCreateComponent = (function () {
    function ContractorCreateComponent(http, _ContractorService, router) {
        this.http = http;
        this._ContractorService = _ContractorService;
        this.router = router;
        this.contractor_error = new error_1.ErrorModel();
        this.contractor = new contractor_1.contractorDataModel();
    }
    ContractorCreateComponent.prototype.addContractor = function (email) {
        var _this = this;
        if (email != '') {
            this._ContractorService.createContractor('/contractor', '', email).subscribe(function (data) {
                _this.contractor = data;
                _this.modal.close();
                _this.router.navigate(['/settings/contractor/']);
            }, function (err) {
                _this.contractor_error = err.json();
                // this.contractor_error.message = err.status;
                //this.contractor_error.FieldValidationErrors = err._body;
            });
        }
        else
            this.emVal = true;
    };
    ContractorCreateComponent.prototype.formStatus = function (e) {
        console.log(e);
        this.invEmail = false;
        this.emVal = e == null ? true : false;
    };
    ContractorCreateComponent.prototype.ngOnInit = function () {
        this.modal.open();
    };
    ContractorCreateComponent.prototype.close = function () {
        this.modal.close();
        this.router.navigate(['/settings/contractor/']);
    };
    ContractorCreateComponent.prototype.open = function () {
        this.modal.open();
    };
    __decorate([
        core_1.ViewChild('myModal'), 
        __metadata('design:type', ng2_bs3_modal_1.ModalComponent)
    ], ContractorCreateComponent.prototype, "modal", void 0);
    ContractorCreateComponent = __decorate([
        core_1.Component({
            selector: 'project_edit',
            templateUrl: './app/contractor/contractor-add.html',
            directives: [ng2_bs3_modal_1.MODAL_DIRECTIVES],
        }), 
        __metadata('design:paramtypes', [http_1.Http, contractor_service_1.ContractorService, router_1.Router])
    ], ContractorCreateComponent);
    return ContractorCreateComponent;
}());
exports.ContractorCreateComponent = ContractorCreateComponent;
//# sourceMappingURL=contractor-add.component.js.map