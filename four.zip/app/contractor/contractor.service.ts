import { Injectable }    from '@angular/core';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ContractorService {
    private headers = new Headers({'Content-Type': 'application/json'});
    private baseUrl = 'http://localhost:9090/atlis/';  // URL to web api
    constructor(private http: Http) { }
    getContractors(url,baseUrl){
        if(baseUrl!=''){
            this.baseUrl = baseUrl;
        }
        return this.http.get(this.baseUrl+url)
            .map(response => response.json());
    }
    createContractor(url,baseUrl,email){
        console.log(email);
        if(baseUrl!=''){
            this.baseUrl = baseUrl;
        }
        return this.http.post(this.baseUrl+url,JSON.stringify({contractorEmail: email}),{headers: this.headers})
            .map(response => response.json());
    }
    getContractor(url,baseUrl){
        if(baseUrl!=''){
            this.baseUrl = baseUrl;
        }
        return this.http.get(this.baseUrl+url)
            .map(response => response.json());
    }
    saveContractor(url,baseUrl,email){
        if(baseUrl!=''){
            this.baseUrl = baseUrl;
        }
        return this.http.put(this.baseUrl+url,JSON.stringify({contractorEmail: email}),{headers: this.headers})
            .map(response => response.json());
    }
    updateContractor(url,baseUrl){
        if(baseUrl!=''){
            this.baseUrl = baseUrl;
        }
        return this.http.get(this.baseUrl+url)
            .map(response => response.json());
    }
    deleteContractor(url,baseUrl){
        if(baseUrl!=''){
            this.baseUrl = baseUrl;
        }
        return this.http.delete(this.baseUrl+url)
            .map(response => response.json());
    }
}
