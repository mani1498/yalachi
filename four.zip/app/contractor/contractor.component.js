"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require('@angular/router');
var contractor_service_1 = require('../contractor/contractor.service');
var ng2_bs3_modal_1 = require('ng2-bs3-modal/ng2-bs3-modal');
var contractor_1 = require('../contractor/contractor');
var error_1 = require('../contractor/error');
var ContractorComponent = (function () {
    function ContractorComponent(http, _ContractorService, router) {
        this.http = http;
        this._ContractorService = _ContractorService;
        this.router = router;
        this.contractor_error = new error_1.ErrorModel();
        this.contractor = new contractor_1.contractorDataModel();
    }
    ContractorComponent.prototype.getProducts = function () {
        var _this = this;
        this._ContractorService.getContractors('/contractor', '').subscribe(function (data) {
            _this.contractors = data;
        }, function (err) {
            _this.contractor_error = err.json();
        });
    };
    ContractorComponent.prototype.ngOnInit = function () {
        console.log('re');
        this.getProducts();
    };
    ContractorComponent.prototype.open = function () {
        this.modal.open();
    };
    __decorate([
        core_1.ViewChild('myModal'), 
        __metadata('design:type', ng2_bs3_modal_1.ModalComponent)
    ], ContractorComponent.prototype, "modal", void 0);
    ContractorComponent = __decorate([
        core_1.Component({
            selector: 'project',
            templateUrl: './app/contractor/contractor.html',
            directives: [ng2_bs3_modal_1.MODAL_DIRECTIVES],
        }), 
        __metadata('design:paramtypes', [http_1.Http, contractor_service_1.ContractorService, router_1.Router])
    ], ContractorComponent);
    return ContractorComponent;
}());
exports.ContractorComponent = ContractorComponent;
//# sourceMappingURL=contractor.component.js.map