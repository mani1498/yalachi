import { Component, ViewChild} from '@angular/core';
import {  Http, Response } from '@angular/http';
import { Router,ActivatedRoute }            from '@angular/router';
import { ContractorService }  from '../contractor/contractor.service';
import { MODAL_DIRECTIVES,ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';

import { contractorDataModel }  from '../contractor/contractor';
import { ErrorModel }  from '../contractor/error';

@Component({
    selector: 'project',
    templateUrl: './app/contractor/contractor.html',
    directives: [MODAL_DIRECTIVES],
})
export class ContractorComponent {
    public contractors;
    public contractor:contractorDataModel;
    public contractor_error:ErrorModel;
    @ViewChild('myModal')
    modal: ModalComponent;
    constructor(private http: Http, private _ContractorService : ContractorService, private router: Router) { 
         this.contractor_error = new ErrorModel();
        this.contractor = new contractorDataModel();
    }
    getProducts(){
        this._ContractorService.getContractors('/contractor','').subscribe(data=>{
            this.contractors=data;
        },
        err => { this.contractor_error = err.json();
            });
    }
    ngOnInit() {console.log('re');
        this.getProducts();
    }
     public open() {
        this.modal.open();
    }
}

