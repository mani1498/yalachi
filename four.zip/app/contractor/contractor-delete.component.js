"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require('@angular/router');
var contractor_service_1 = require('../contractor/contractor.service');
var ng2_bs3_modal_1 = require('ng2-bs3-modal/ng2-bs3-modal');
var contractor_1 = require('../contractor/contractor');
var error_1 = require('../contractor/error');
var ContractorDeleteComponent = (function () {
    function ContractorDeleteComponent(http, _ContractorService, router, activatedRoute) {
        this.http = http;
        this._ContractorService = _ContractorService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.contractor_error = new error_1.ErrorModel();
        this.contractor = new contractor_1.contractorDataModel();
    }
    ContractorDeleteComponent.prototype.getContractor = function () {
        var _this = this;
        this.activatedRoute.params.subscribe(function (params) {
            _this.params = params;
        });
        this._ContractorService.getContractor('/contractor/' + this.params.id, '').subscribe(function (data) {
            _this.contractor.contractorEmail = data.contractorEmail;
            _this.contractor.contractorId = data.id;
        });
    };
    ContractorDeleteComponent.prototype.deleteContractor = function (id) {
        var _this = this;
        this._ContractorService.deleteContractor('/contractor/' + id, '').subscribe(function (data) {
            _this.contractor = data;
            _this.router.navigate(['/settings/contractor']);
        }, function (err) {
            _this.contractor_error = err.json();
        });
    };
    ContractorDeleteComponent.prototype.ngOnInit = function () {
        this.getContractor();
        this.modal.open();
    };
    ContractorDeleteComponent.prototype.close = function () {
        this.modal.close();
        this.router.navigate(['/settings/contractor/']);
    };
    ContractorDeleteComponent.prototype.open = function () {
        this.modal.open();
    };
    __decorate([
        core_1.ViewChild('myModal'), 
        __metadata('design:type', ng2_bs3_modal_1.ModalComponent)
    ], ContractorDeleteComponent.prototype, "modal", void 0);
    ContractorDeleteComponent = __decorate([
        core_1.Component({
            selector: 'project_edit',
            templateUrl: './app/contractor/contractor-delete.html',
            directives: [ng2_bs3_modal_1.MODAL_DIRECTIVES],
        }), 
        __metadata('design:paramtypes', [http_1.Http, contractor_service_1.ContractorService, router_1.Router, router_1.ActivatedRoute])
    ], ContractorDeleteComponent);
    return ContractorDeleteComponent;
}());
exports.ContractorDeleteComponent = ContractorDeleteComponent;
//# sourceMappingURL=contractor-delete.component.js.map