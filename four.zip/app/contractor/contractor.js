"use strict";
var contractorDataModel = (function () {
    function contractorDataModel() {
    }
    return contractorDataModel;
}());
exports.contractorDataModel = contractorDataModel;
//# sourceMappingURL=contractor.js.map