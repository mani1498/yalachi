export class ErrorModel{
    timestamp: number;
    message : string;
    status : string;
    FieldValidationErrors: string;    
}