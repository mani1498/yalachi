import { Component, ViewChild} from '@angular/core';
import {  Http, Response } from '@angular/http';
import { Router,ActivatedRoute }            from '@angular/router';
import { ContractorService }  from '../contractor/contractor.service';
import { MODAL_DIRECTIVES,ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';


@Component({
    selector: 'project_list',
    template: '',
    directives: [MODAL_DIRECTIVES],
})
export class ContractorListComponent {

}
