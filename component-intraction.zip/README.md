### Angular 2 Documentation Example 

Component Communication Cookbook samples