### Angular 2 Documentation Example 

Structural directives