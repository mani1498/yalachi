### Angular 2 Documentation Example 

Dependency Injection